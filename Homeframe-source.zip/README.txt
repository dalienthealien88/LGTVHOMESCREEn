HOMEFRAME 2.0.3 — TV launcher with Bazaar lists

Use the remote arrows and OK. Bazaar Home, Continue watching, Watchlist, Favourites, My lists, New episodes, Release calendar, Live & guide and Library open the live Bazaar pages in the TV browser. Sign into Bazaar in the TV browser first. Netflix and the other app buttons launch the corresponding TV apps.

This is a simple launcher and does not replace LG Home. Bazaar uses HTTP; use it only on a trusted home network.
