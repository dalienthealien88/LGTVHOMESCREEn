The Bazaar — full-screen webOS TV app

The app opens The Bazaar directly as a top-level page so its sign-in form and TV-side session cookie work. Credentials are entered on the Bazaar website and are not collected by this app.

This uses HTTP. Use it only on a trusted home network. Sign in on the TV; desktop browser sessions are separate.

Build the IPK with Node.js and tar by running build-ipk.cjs.
