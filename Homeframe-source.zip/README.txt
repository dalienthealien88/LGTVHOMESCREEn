The Bazaar — full-screen webOS TV app

This replaces the Homeframe dashboard with The Bazaar compatibility home shown edge-to-edge inside the app. No Homeframe menu, dock, external scripts or local server is used.

The address is HTTP. Use the app only on a trusted home network. Sign in on the TV; desktop browser sessions are separate.

Build the IPK with Node.js and tar by running build-ipk.cjs.
