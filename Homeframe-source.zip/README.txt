HOMEFRAME 2.0.2 — Simple webOS TV launcher

INSTALL
Install Homeframe 2.0.2 from Homebrew Channel and open it from the TV launcher.

USE
Use the remote arrows to select an app and OK to open it. The Bazaar opens in the TV browser. Other buttons launch installed webOS apps. If an app does not open, its app ID may differ on the TV.

This is a basic launcher and does not replace LG Home.
