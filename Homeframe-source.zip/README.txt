The Bazaar — full-screen webOS TV app

Opens The Bazaar full interface directly in the TV app, allowing pointer-style navigation where supported by the TV remote. Sign in on The Bazaar page so the site handles its own login and session. The app does not collect or store passwords.

This uses HTTP. Use it only on a trusted home network. Sign in on the TV; desktop browser sessions are separate.

Build the IPK with Node.js and tar by running build-ipk.cjs.
