The Bazaar — full-screen webOS TV app

Displays a remote-friendly sign-in form and submits it directly to The Bazaar server. The site's successful login creates the TV-side session and opens the compatibility home. The app does not store passwords.

This uses HTTP. Use it only on a trusted home network. Sign in on the TV; desktop browser sessions are separate.

Build the IPK with Node.js and tar by running build-ipk.cjs.
