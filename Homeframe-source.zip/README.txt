HOMEFRAME 1.0.0 — LG webOS TV launcher concept

This is a standalone webOS TV app package. It does not replace LG Home or remap the remote's Home button.

INSTALL
1. Enable Developer Mode on the TV and note the webOS version.
2. Add the TV as a device in webOS Dev Manager / webOS TV CLI.
3. Install Homeframe.ipk from the app's launcher list.
4. Open Homeframe from the TV's app launcher.

USING
- Move between tiles with the directional pad and press OK to launch.
- Choose Edit shortcuts to change names and webOS app IDs.
- Use the remote's Home button to leave the app. The on-screen Return to LG Home button also asks webOS to open its Home app.

NOTES
- App IDs can vary by app, TV region, and firmware. Edit shortcuts is provided because LG does not expose a dependable public installed-app listing for ordinary third-party apps.
- This first package targets a modern webOS TV runtime and has not yet been installed on the owner's TV. Verify the webOS version and test this standalone package before considering any Home-screen takeover.
- Home takeover is not included. Any future takeover needs a verified recovery route and should be built as a separate, reversible step.
- The included webOSTV.js and webOSTV-dev.js are from the official webOS-TV-app-samples/webOSTVJSLibrary project.
