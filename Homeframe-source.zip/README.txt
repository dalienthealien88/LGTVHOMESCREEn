HOMEFRAME 2.0.1 — The Bazaar TV home

This is a standalone webOS TV app package. It does not replace LG Home or remap the remote's Home button.

INSTALL
1. Enable Developer Mode on the TV and note the webOS version.
2. Add the TV as a device in webOS Dev Manager / webOS TV CLI.
3. Install Homeframe.ipk from the app's launcher list.
4. Open Homeframe from the TV's app launcher.

USING
- The main panel opens The Bazaar compatibility view, which provides Home, Library, Live, IPTV, radio, EPG, Watchlist, Release Calendar and New Episodes.
- Use the row above the panel to jump between Bazaar sections. Use the bottom app dock to launch Netflix, Prime Video, YouTube, Disney+ or Live TV.
- Choose Apps to change the native webOS app IDs. IDs can vary by TV region and firmware.
- Use the remote's Home button to leave the app.

NOTES
- App IDs can vary by app, TV region, and firmware. Edit shortcuts is provided because LG does not expose a dependable public installed-app listing for ordinary third-party apps.
- The Bazaar view loads from the supplied network address inside the app. Sign-in is separate from the desktop browser session and must be done on the TV.
- The supplied Bazaar address uses HTTP. Do not enter a password over an untrusted network; configure HTTPS before using credentials over the public internet.
- This update removes JavaScript features and DOM methods that older webOS TV browsers may fail to parse or run. It has not yet been verified on the target TV; confirm that it launches, then verify remote navigation, sign-in, playback and app IDs.
- Home takeover is not included. Any future takeover needs a verified recovery route and should be built as a separate, reversible step.
- The included webOSTV.js and webOSTV-dev.js are from the official webOS-TV-app-samples/webOSTVJSLibrary project.

