const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const zlib = require('zlib');
const base = __dirname;
const out = path.join(base, 'Homeframe.ipk');
const tmp = path.join(base, '.package');
fs.rmSync(tmp, {recursive:true, force:true});
fs.mkdirSync(path.join(tmp, 'control'), {recursive:true});
fs.mkdirSync(path.join(tmp, 'usr', 'palm', 'applications', 'com.homeframe.launcher'), {recursive:true});
const app = path.join(tmp, 'usr', 'palm', 'applications', 'com.homeframe.launcher');
for (const name of ['appinfo.json','index.html','bazaar-logo-3.0.9.png','bazaar-logo-3.0.9-80.png','bazaar-logo-3.0.9-130.png','README.txt']) fs.copyFileSync(path.join(base,name), path.join(app,name));
fs.writeFileSync(path.join(tmp, 'control', 'control'), [
  'Package: com.homeframe.launcher', 'Version: 3.0.9', 'Architecture: all',
  'Description: The Bazaar full-screen TV app', 'Maintainer: Homeframe',
  'Section: misc', 'Priority: optional', ''
].join('\n'));
function tarGzip(cwd, paths) {
  const result = cp.spawnSync('tar', ['-czf','-','-C',cwd,...paths], {encoding:null, maxBuffer:16*1024*1024});
  if (result.status !== 0) throw new Error((result.stderr||Buffer.from('tar failed')).toString());
  return result.stdout;
}
function arHeader(name, data) {
  const h = Buffer.alloc(60, 32);
  h.write(name + '/', 0, 16, 'ascii'); h.write('0',16,12,'ascii'); h.write('0',28,6,'ascii');
  h.write('0',34,6,'ascii'); h.write('100644',40,8,'ascii'); h.write(String(data.length),48,10,'ascii');
  h.write('`\n',58,2,'ascii'); return h;
}
const parts = [
  ['debian-binary', Buffer.from('2.0\n')],
  ['control.tar.gz', tarGzip(path.join(tmp,'control'), ['./control'])],
  ['data.tar.gz', tarGzip(tmp, ['./usr'])]
];
const outParts = [Buffer.from('!<arch>\n')];
for (const [name,data] of parts) { outParts.push(arHeader(name,data), data); if (data.length % 2) outParts.push(Buffer.from('\n')); }
fs.writeFileSync(out, Buffer.concat(outParts));
console.log(out + ' (' + fs.statSync(out).size + ' bytes)');



