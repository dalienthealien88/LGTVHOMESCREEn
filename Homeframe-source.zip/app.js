(function () {
  var buttons = document.getElementById('apps').getElementsByTagName('button');
  var status = document.getElementById('status');
  var selected = 0;
  var columns = 3;

  function launch(button) {
    var appId = button.getAttribute('data-id');
    var target = button.getAttribute('data-url');
    if (!window.PalmServiceBridge) {
      status.innerText = 'TV launch service is unavailable.';
      return;
    }
    var request = new PalmServiceBridge();
    request.onservicecallback = function (raw) {
      var result;
      try { result = JSON.parse(raw); } catch (e) { result = null; }
      if (result && result.returnValue) status.innerText = 'Opening ' + button.innerText + '…';
      else status.innerText = button.innerText + ' could not be opened. Check the TV app is installed.';
    };
    var params = { id: appId };
    if (target) params.params = { target: target };
    request.call('luna://com.webos.applicationManager/launch', JSON.stringify(params));
    status.innerText = 'Opening ' + button.innerText + '…';
  }

  function focusSelected() {
    if (buttons[selected]) buttons[selected].focus();
  }

  for (var i = 0; i < buttons.length; i++) {
    (function (button) { button.onclick = function () { launch(button); }; })(buttons[i]);
  }

  document.addEventListener('keydown', function (event) {
    var key = event.keyCode || event.which;
    var next = selected;
    if (key === 37 && selected % columns > 0) next = selected - 1;
    else if (key === 39 && selected % columns < columns - 1 && selected + 1 < buttons.length) next = selected + 1;
    else if (key === 38 && selected - columns >= 0) next = selected - columns;
    else if (key === 40 && selected + columns < buttons.length) next = selected + columns;
    else if (key === 13) {
      event.preventDefault();
      launch(buttons[selected]);
      return;
    } else return;
    event.preventDefault();
    selected = next;
    focusSelected();
  }, false);

  focusSelected();
}());
