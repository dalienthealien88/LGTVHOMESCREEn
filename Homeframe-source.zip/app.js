(() => {
  const portalBase = 'http://thebazaar.duckdns.org:9999/?compat=on';
  const views = [
    ['home', 'Home'], ['library', 'Library'], ['live', 'Live & guide'],
    ['watchlist', 'Watchlist'], ['calendar', 'Calendar'], ['arrivals', 'New episodes']
  ];
  const defaults = [
    {name:'Netflix', id:'netflix', icon:'N', tone:'netflix'},
    {name:'Prime Video', id:'amazon', icon:'prime', tone:'prime'},
    {name:'YouTube', id:'youtube.leanback.v4', icon:'▶', tone:'youtube'},
    {name:'Disney+', id:'com.disney.disneyplus-prod', icon:'✦', tone:'disney'},
    {name:'Live TV', id:'com.webos.app.livetv', icon:'◉', tone:'livetv'}
  ];
  const storageKey = 'homeframe.shortcuts.v2';
  let items;
  try { items = JSON.parse(localStorage.getItem(storageKey)) || defaults.map(item=>({...item})); }
  catch (_) { items = defaults.map(item=>({...item})); }

  const frame = document.getElementById('portalFrame');
  const nav = document.getElementById('portalNav');
  const dock = document.getElementById('appDock');
  const dialog = document.getElementById('settingsDialog');
  const toast = document.getElementById('toast');
  let currentView = 'home', toastTimer;

  function say(message) {
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(()=>toast.classList.remove('show'), 3000);
  }

  function setView(view) {
    if (!views.some(([id])=>id===view)) view = 'home';
    currentView = view;
    const target = new URL(portalBase);
    if (view !== 'home') target.searchParams.set('view', view);
    frame.src = target.href;
    nav.querySelectorAll('[data-view]').forEach(button=>{
      const active = button.dataset.view === view;
      button.classList.toggle('active', active);
      if (active) button.setAttribute('aria-current','page');
      else button.removeAttribute('aria-current');
    });
  }

  function launch(item) {
    if (!item.id) { say(`Set the webOS app ID for ${item.name} in Apps.`); return; }
    if (window.webOSDev?.launch) {
      window.webOSDev.launch({
        id:item.id,
        onSuccess:()=>{},
        onFailure:error=>say(error?.errorText || `Could not open ${item.name}. Check its app ID in Apps.`)
      });
    } else say(`${item.name} is ready to open on the TV.`);
  }

  function drawApps() {
    dock.replaceChildren();
    items.slice(0,8).forEach((item,index)=>{
      const button=document.createElement('button');
      button.type='button';
      button.className=`app-tile ${item.tone||'custom'}`;
      button.dataset.index=index;
      button.setAttribute('aria-label',`Open ${item.name}`);
      const icon=document.createElement('span');
      icon.className='app-icon';
      icon.textContent=item.icon||'◇';
      const label=document.createElement('span');
      label.className='app-name';
      label.textContent=item.name||'App';
      button.append(icon,label);
      button.addEventListener('click',()=>launch(item));
      dock.append(button);
    });
  }

  function openSettings() {
    const list=document.getElementById('shortcutList');
    list.replaceChildren();
    defaults.forEach((fallback,index)=>{
      const current=items[index]||fallback;
      for(const [labelText,key,value,placeholder] of [
        ['App name','name',current.name,'App name'],
        ['webOS app ID','id',current.id,'com.example.app']
      ]) {
        const label=document.createElement('label');
        label.textContent=`${fallback.name} · ${labelText}`;
        const input=document.createElement('input');
        input.name=`${key}-${index}`;
        input.value=value||'';
        input.placeholder=placeholder;
        input.autocomplete='off';
        label.append(input);
        list.append(label);
      }
    });
    dialog.showModal();
    list.querySelector('input')?.focus();
  }

  document.getElementById('settingsForm').addEventListener('submit',event=>{
    if (event.submitter?.value !== 'save') return;
    event.preventDefault();
    const values=new FormData(event.currentTarget);
    items=defaults.map((fallback,index)=>({
      ...fallback,
      name:String(values.get(`name-${index}`)||fallback.name).trim(),
      id:String(values.get(`id-${index}`)||'').trim()
    }));
    localStorage.setItem(storageKey,JSON.stringify(items));
    dialog.close();
    drawApps();
    say('App shortcuts saved.');
  });

  document.getElementById('resetButton').addEventListener('click',()=>{
    items=defaults.map(item=>({...item}));
    localStorage.removeItem(storageKey);
    dialog.close();
    drawApps();
    say('Default app shortcuts restored.');
  });

  function focusables() {
    return [...document.querySelectorAll('button:not([disabled]),input:not([disabled]),iframe,a[href],[tabindex]:not([tabindex="-1"])')]
      .filter(element=>element.getClientRects().length && !element.closest('[inert]'));
  }

  function moveFocus(direction) {
    const current=document.activeElement;
    const candidates=focusables().filter(element=>element!==current);
    if (!candidates.length) return;
    const from=current.getBoundingClientRect();
    const x=from.left+from.width/2, y=from.top+from.height/2;
    let best=null, bestScore=Infinity;
    for (const element of candidates) {
      const rect=element.getBoundingClientRect();
      const dx=rect.left+rect.width/2-x, dy=rect.top+rect.height/2-y;
      const primary=direction==='left'?-dx:direction==='right'?dx:direction==='up'?-dy:dy;
      if (primary<=1) continue;
      const secondary=(direction==='left'||direction==='right')?Math.abs(dy):Math.abs(dx);
      const score=primary+secondary*2.4+secondary*secondary/Math.max(primary,1)*0.35;
      if (score<bestScore) { best=element; bestScore=score; }
    }
    best?.focus({preventScroll:true});
  }

  function back() {
    if (dialog.open) { dialog.close(); return true; }
    if (currentView !== 'home') { setView('home'); return true; }
    return false;
  }

  function exit() {
    if (window.webOS?.platform?.back) { window.webOS.platform.back(); return; }
    if (window.webOSDev?.launch) { window.webOSDev.launch({id:'com.webos.app.home'}); return; }
    say('Use the TV remote Home button to return to LG Home.');
  }

  function updateClock() {
    const now=new Date();
    document.getElementById('clock').textContent=new Intl.DateTimeFormat(undefined,{hour:'numeric',minute:'2-digit'}).format(now);
    document.getElementById('date').textContent=new Intl.DateTimeFormat(undefined,{weekday:'short',month:'short',day:'numeric'}).format(now).toUpperCase();
  }

  nav.addEventListener('click',event=>{
    const button=event.target.closest('[data-view]');
    if (button) setView(button.dataset.view);
  });
  document.getElementById('settingsButton').addEventListener('click',openSettings);
  document.getElementById('homeButton').addEventListener('click',exit);
  frame.addEventListener('load',()=>document.querySelector('.portal-stage')?.classList.add('ready'));

  document.addEventListener('keydown',event=>{
    const key=event.key, code=event.keyCode||event.which;
    const directions={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'up',ArrowDown:'down'};
    const direction=directions[key]||({37:'left',39:'right',38:'up',40:'down'})[code];
    if (direction) { event.preventDefault(); moveFocus(direction); return; }
    if (key==='Escape'||key==='Backspace'||code===461||code===8) {
      if (back()) event.preventDefault();
      return;
    }
    if (key==='Menu'||key==='F2'||code===18) { event.preventDefault(); openSettings(); return; }
    if (key==='Home') { event.preventDefault(); exit(); }
  },true);
  document.addEventListener('webOSPlatformBack',()=>{if(!back())exit();});

  drawApps();
  updateClock();
  nav.querySelector('[data-view="home"]')?.focus({preventScroll:true});
  setInterval(updateClock,15000);
  setView('home');
})();
