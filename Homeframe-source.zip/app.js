(function () {
  var buttons = document.getElementById('apps').getElementsByTagName('button');
  var status = document.getElementById('status');
  var selected = 0;

  function message(text) {
    status.innerText = text;
  }

  function focusSelected() {
    if (buttons[selected]) buttons[selected].focus();
  }

  function launch(button) {
    var appId = button.getAttribute('data-id');
    var target = button.getAttribute('data-url');
    if (!window.PalmServiceBridge) {
      message('TV launch service is unavailable.');
      return;
    }
    var request = new PalmServiceBridge();
    request.onservicecallback = function (raw) {
      var result;
      try { result = JSON.parse(raw); } catch (e) { result = null; }
      if (result && result.returnValue) message('Opening ' + button.innerText + '…');
      else message((button.innerText || appId) + ' could not be opened. Check that it is installed.');
    };
    var params = { id: appId };
    if (target) params.params = { target: target };
    request.call('luna://com.webos.applicationManager/launch', JSON.stringify(params));
    message('Opening ' + button.innerText + '…');
  }

  for (var i = 0; i < buttons.length; i++) {
    (function (button) {
      button.onclick = function () { launch(button); };
    })(buttons[i]);
  }

  document.addEventListener('keydown', function (event) {
    var key = event.keyCode || event.which;
    var next = selected;
    if (key === 37 && selected % 2 === 1) next = selected - 1;
    else if (key === 39 && selected % 2 === 0 && selected + 1 < buttons.length) next = selected + 1;
    else if (key === 38 && selected - 2 >= 0) next = selected - 2;
    else if (key === 40 && selected + 2 < buttons.length) next = selected + 2;
    else if (key === 13 || key === 461) {
      event.preventDefault();
      if (key === 13) launch(buttons[selected]);
      return;
    } else return;
    event.preventDefault();
    selected = next;
    focusSelected();
  }, false);

  focusSelected();
}());
