(() => {
  const defaults = [
    {name:'Netflix', id:'netflix', icon:'▣', sub:'Movies & series'},
    {name:'YouTube', id:'youtube.leanback.v4', icon:'▶', sub:'Videos for you'},
    {name:'Prime Video', id:'amazon', icon:'◒', sub:'Originals & more'},
    {name:'Disney+', id:'com.disney.disneyplus-prod', icon:'✦', sub:'Stories to explore'},
    {name:'TV', id:'com.webos.app.livetv', icon:'⌁', sub:'Live television'}
  ];
  const key='homeframe.shortcuts';
  let items;
  try { items = JSON.parse(localStorage.getItem(key)) || defaults; } catch (_) { items = defaults; }
  const tiles=document.getElementById('tiles'), dialog=document.getElementById('settingsDialog'), toast=document.getElementById('toast');
  let toastTimer;
  function say(message){toast.textContent=message;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2600)}
  function draw(){
    tiles.replaceChildren();
    items.slice(0,8).forEach((item,index)=>{
      const tile=document.createElement('button');tile.className='tile';tile.type='button';tile.setAttribute('role','listitem');tile.dataset.index=index;
      const icon=document.createElement('span');icon.className='tile-icon';icon.textContent=item.icon||'◇';
      const text=document.createElement('span');text.innerHTML=`<span class="tile-name"></span><span class="tile-sub"></span>`;text.querySelector('.tile-name').textContent=item.name||'App';text.querySelector('.tile-sub').textContent=item.sub||'Your shortcut';
      tile.append(icon,text);tile.addEventListener('click',()=>launch(item));tiles.append(tile);
    });
    tiles.querySelector('.tile')?.focus();
  }
  function launch(item){
    if(!item.id){say('Add this app’s webOS ID in Edit shortcuts.');return;}
    if(window.webOSDev?.launch){webOSDev.launch({id:item.id,onSuccess:()=>{},onFailure:(error)=>say(error?.errorText||`Could not open ${item.name}. Check its app ID.`)});}
    else say(`Ready to open ${item.name} (${item.id}) on the TV.`);
  }
  function back(){if(dialog.open){dialog.close();return true}return false}
  function exit(){if(window.webOS?.platform?.back){webOS.platform.back();return}if(window.webOSDev?.launch){webOSDev.launch({id:'com.webos.app.home'});return}say('Use the TV remote Home button to return to LG Home.');}
  function tick(){const now=new Date();document.getElementById('clock').textContent=new Intl.DateTimeFormat(undefined,{hour:'numeric',minute:'2-digit'}).format(now);document.getElementById('date').textContent=new Intl.DateTimeFormat(undefined,{weekday:'long',month:'long',day:'numeric'}).format(now).toUpperCase()}
  document.getElementById('homeButton').addEventListener('click',exit);
  document.getElementById('settingsButton')?.addEventListener('click',()=>openSettings());
  function openSettings(){
    const list=document.getElementById('shortcutList');list.replaceChildren();
    defaults.forEach((item,index)=>{
      const current=items[index]||item;
      for(const [labelText,keyName,value,placeholder] of [['App name','name',current.name,'App name'],['webOS app ID','id',current.id,'com.example.app']]){
        const label=document.createElement('label');label.textContent=`${index+1}. ${labelText}`;
        const input=document.createElement('input');input.name=`${keyName}-${index}`;input.value=value||'';input.placeholder=placeholder;input.autocomplete='off';
        label.append(input);list.append(label);
      }
    });
    dialog.showModal();list.querySelector('input')?.focus();
  }
  document.getElementById('settingsForm').addEventListener('submit',event=>{
    if(event.submitter?.value!=='save')return;
    event.preventDefault();const values=new FormData(event.currentTarget);
    items=defaults.map((item,index)=>({...item,name:String(values.get(`name-${index}`)||item.name).trim(),id:String(values.get(`id-${index}`)||'').trim()}));
    localStorage.setItem(key,JSON.stringify(items));dialog.close();draw();say('Shortcuts saved.');
  });
  document.getElementById('resetButton').addEventListener('click',()=>{items=defaults.map(item=>({...item}));localStorage.removeItem(key);dialog.close();draw();say('Default shortcuts restored.');});
  document.addEventListener('keydown',event=>{
    if(event.key==='Escape'||event.key==='Backspace'){if(back())event.preventDefault();return}
    if(event.key==='Menu'||event.key==='F2'){openSettings();return}
    if(event.key==='Home'){exit();return}
    if(event.key==='Enter'&&document.activeElement===document.body){tiles.querySelector('.tile')?.click()}
  });
  document.addEventListener('webOSPlatformBack',()=>{if(!back())exit()});
  draw();tick();setInterval(tick,15000);
})();
