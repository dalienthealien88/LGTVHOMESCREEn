const fs=require('fs'),zlib=require('zlib');
const w=128,h=128,rows=[];
function insideTri(x,y,a,b,c){let s=(p1,p2,p3)=>(p1[0]-p3[0])*(p2[1]-p3[1])-(p2[0]-p3[0])*(p1[1]-p3[1]);let p=[x,y],d1=s(p,a,b),d2=s(p,b,c),d3=s(p,c,a);return !(d1<0||d2<0||d3<0)&&!(d1>0||d2>0||d3>0);}
for(let y=0;y<h;y++){let row=Buffer.alloc(1+w*4);for(let x=0;x<w;x++){let dx=x-64,dy=y-64,d=Math.sqrt(dx*dx+dy*dy),col=[19,32,55,255];if(d>51&&d<57)col=[103,214,255,255];if(insideTri(x,y,[48,35],[91,64],[48,93]))col=[245,249,255,255];let i=1+x*4;row.set(col,i);}rows.push(row);}
function crc(buf){let c=0xffffffff;for(let b of buf){c^=b;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;}return (c^0xffffffff)>>>0;}
function chunk(type,data){let t=Buffer.from(type),len=Buffer.alloc(4),sum=Buffer.alloc(4);len.writeUInt32BE(data.length);sum.writeUInt32BE(crc(Buffer.concat([t,data])));return Buffer.concat([len,t,data,sum]);}
let ih=Buffer.alloc(13);ih.writeUInt32BE(w,0);ih.writeUInt32BE(h,4);ih[8]=8;ih[9]=6;
let png=Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',zlib.deflateSync(Buffer.concat(rows))),chunk('IEND',Buffer.alloc(0))]);fs.writeFileSync('BazaarFullScreen/icon.png',png);
